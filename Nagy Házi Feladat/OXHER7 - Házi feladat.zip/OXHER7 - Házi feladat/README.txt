A futtatható binary a "Házi Feladat/bin/Debug/Házi\ Feladat" linuxra lett compile-olva de windowson is futnia kellene.
A build és compile beállítások a CodeBlocks projekt fileban vanak.
