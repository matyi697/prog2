#ifndef STATION_H
#define STATION_H

#include <string>
#include "train.h"

using namespace std;

class Station
{

};

#endif // STATION_H
