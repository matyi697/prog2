#include "vikworldPrint.h"

extern void hello();

int main()
{
	hello();
	vikworld();
	return 0;
}